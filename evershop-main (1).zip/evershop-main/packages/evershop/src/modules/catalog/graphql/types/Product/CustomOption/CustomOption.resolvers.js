module.exports = {
  Product: {
    options: async (product, _, { pool }) => [] // TODO: To be implemented

  }
};
