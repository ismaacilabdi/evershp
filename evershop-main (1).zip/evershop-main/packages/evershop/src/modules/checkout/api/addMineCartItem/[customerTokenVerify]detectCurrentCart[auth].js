const detectCurrentCartMiddleware = require('../../pages/frontStore/all/[customerTokenVerify]detectCurrentCart[auth]');

module.exports = detectCurrentCartMiddleware;
